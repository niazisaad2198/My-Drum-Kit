var no_of_buttons = document.querySelectorAll("button").length;
var list_of_sounds = ["sounds/tom-1.mp3","sounds/tom-2.mp3","sounds/tom-3.mp3","sounds/tom-4.mp3","sounds/snare.mp3","sounds/crash.mp3","sounds/kick-bass.mp3"];
var list_of_buttons = document.querySelectorAll("button");

for(var i = 0; i<no_of_buttons; i++){
    document.querySelectorAll("button")[i].Audio = new Audio(list_of_sounds[i]);
    document.querySelectorAll("button")[i].addEventListener("click", function (){
        animateButton(this.innerHTML);
        this.Audio.play();
    });

    document.querySelectorAll("button")[i].addEventListener("keypress", function (event){
        switch(event.key){
            case 'w': {
                animateButton("w");
                list_of_buttons[0].Audio.play();
                break;
            }

            case 'a': {
                animateButton("a");
                list_of_buttons[1].Audio.play();
                break;
            }

            case 's': {
                animateButton("s");
                list_of_buttons[2].Audio.play();
                break;
            }

            case 'd': {
                animateButton("d");
                list_of_buttons[3].Audio.play();
                break;
            }

            case 'j': {
                animateButton("j");
                list_of_buttons[4].Audio.play();
                break;
            }

            case 'k': {
                animateButton("k");
                list_of_buttons[5].Audio.play();
                break;
            }

            case 'l': {
                animateButton("l");
                list_of_buttons[6].Audio.play();
                break;
            }

            default:{}
        }

        
    });

    
}

function animateButton(clss){
    document.querySelector("."+clss).classList.add("pressed");

    setTimeout(function () {
        document.querySelector("."+clss).classList.remove("pressed");
    },100);
}

